package com.mydomain.weather;

public class Weather {

	public float lowTemp;
	public float highTemp;
}
