
module weatherlib {
	requires httplib;
	requires gson;

	requires java.sql;
}