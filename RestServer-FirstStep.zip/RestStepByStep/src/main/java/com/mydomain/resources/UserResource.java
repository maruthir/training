package com.mydomain.resources;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.hibernate.Session;

import com.mydomain.model.User;

@Path("/users")
public class UserResource {
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	public List<User> getUsers() {
		Session ses = HibernateUtil.currentSession();
		return ses.createCriteria(User.class).list();
	}

}
