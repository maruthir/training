package com.mydomain;

import java.lang.management.ManagementFactory;

public class ProcessUtil {

    public static long getPid() {
        System.out.println("Running java 8 process id util");
        // name is in the format <pid>@<hostname>. (Usually)
        String jvmName = ManagementFactory.getRuntimeMXBean().getName();

        int index = jvmName.indexOf('@');
        if (index < 1) {
            return 0; // No PID.
        }

        try {
            return Long.parseLong(jvmName.substring(0, index));
        } catch (NumberFormatException nfe) {
            return 0;
        }
    }
}
