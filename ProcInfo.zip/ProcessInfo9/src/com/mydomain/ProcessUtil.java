package com.mydomain;

import java.lang.management.ManagementFactory;

public class ProcessUtil {

    public static long getPid() {
        System.out.println("Running java 9 process id util");
        return ProcessHandle.current().pid();
    }
}
