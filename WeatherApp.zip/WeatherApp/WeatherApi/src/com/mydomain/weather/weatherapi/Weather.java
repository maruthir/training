package com.mydomain.weather.weatherapi;

public class Weather {

	public float lowTemp;
	public float highTemp;
}
