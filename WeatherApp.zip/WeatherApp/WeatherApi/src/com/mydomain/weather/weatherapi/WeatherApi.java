package com.mydomain.weather.weatherapi;

import java.util.ArrayList;
import java.util.List;
import java.util.ServiceLoader;

public interface WeatherApi {
    Weather getTomorrowForecast(String city) throws Exception;
    Weather getWeather(String city) throws Exception;

    static List<WeatherApi> getInstances() {
        ServiceLoader<WeatherApi> services = ServiceLoader.load(WeatherApi.class);
        List<WeatherApi> list = new ArrayList<>();
        services.iterator().forEachRemaining(list::add);
        if (list.isEmpty()) {
            throw new IllegalStateException("No implementations found for WeatherApi service");
        }
        return list;
    }
}
