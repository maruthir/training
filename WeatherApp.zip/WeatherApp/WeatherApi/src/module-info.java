import com.mydomain.weather.weatherapi.WeatherApi;

module WeatherApi {
    exports com.mydomain.weather.weatherapi;
    uses WeatherApi;
}