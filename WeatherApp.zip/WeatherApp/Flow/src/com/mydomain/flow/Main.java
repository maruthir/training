package com.mydomain.flow;

public class Main {

    public static void main(String[] args) throws Exception {
        StringPublisher publisher = new StringPublisher();
        StringSubscriber subscriber = new StringSubscriber();
        publisher.subscribe(subscriber);
        publisher.submit("one");
        publisher.submit("two");
    }

}
