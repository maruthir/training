package com.mydomain.flow;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.Flow.Publisher;
import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.Flow.Subscription;

public class StringPublisher implements Publisher {

    // Support only one subscriber
    private Subscriber subscriber;

    private StringSubscription subscription;

    private Queue<String> dataQueue;

    public StringPublisher() {
        dataQueue = new ConcurrentLinkedDeque<>();
    }

    @Override
    public synchronized void subscribe(Subscriber subscriber) {
        if (this.subscriber != null) {
            throw new IllegalStateException("This publisher supports only one subscriber");
        }
        this.subscriber = subscriber;
        this.subscription = new StringSubscription(dataQueue, subscriber);
        subscriber.onSubscribe(subscription);
    }

    public void submit(String data) {
        dataQueue.add(data);
        subscription.notifyEventAdd();
    }
}

class StringSubscription implements Subscription {

    Queue<String> dataQueue;

    Subscriber subscriber;

    boolean terminated = false;

    int demand = 0;

    public StringSubscription(Queue<String> dataQueue, Subscriber subscriber) {
        this.dataQueue = dataQueue;
        this.subscriber = subscriber;
    }

    @Override
    public void request(long n) {
        if (terminated) {
            return;
        }
        demand += n;
    }

    @Override
    public void cancel() {
        terminated = true;
        subscriber.onComplete();
    }

    public void notifyEventAdd() {
        while (demand > 0) {
            String data = dataQueue.poll();
            if (data != null) {
                subscriber.onNext(data);
                demand--;
            }
        }
    }
}