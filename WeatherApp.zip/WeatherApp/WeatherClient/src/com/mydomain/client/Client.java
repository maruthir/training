package com.mydomain.client;

import com.mydomain.weather.weatherapi.Weather;
import com.mydomain.weather.weatherapi.WeatherApi;

public class Client {

    public static void main(String[] args) throws Exception{
        WeatherApi api = WeatherApi.getInstances().get(0);
        Weather w = api.getTomorrowForecast("bengaluru");
        System.out.println("Forecast for tomorrow max temperature = " + w.highTemp);
    }
}
