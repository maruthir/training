module WeatherClient {
    requires WeatherApi;
}