
module weatherlib {
	requires transitive httplib;
	requires transitive gson;
	requires WeatherApi;

	requires java.sql;

	exports com.mydomain.weather;
	exports com.mydomain.weather.model;
}