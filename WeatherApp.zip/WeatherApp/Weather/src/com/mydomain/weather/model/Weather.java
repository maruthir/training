package com.mydomain.weather.model;

public class Weather {

	public float lowTemp;
	public float highTemp;
}
