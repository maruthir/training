package com.mydomain.weatherplus;

import com.google.gson.Gson;
import com.mydomain.httplib.HttpLib;
import com.mydomain.weather.WeatherService;
import com.mydomain.weather.weatherapi.Weather;
import com.mydomain.weather.weatherapi.WeatherApi;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class WeatherServicePlus implements WeatherApi {

    private final String WEATHER_FORECAST_URL = "http://api.openweathermap.org/data/2.5/forecast?q=CITY&APPID=cc3d457fb9707805588d131ce51804be";
    private final float ZERO_KELVIN = 273.15F;

    public Weather getTomorrowForecast(String city) throws Exception {
        HttpLib lib = new HttpLib();
        String wjson = lib.get(WEATHER_FORECAST_URL.replaceAll("CITY", city));
        Gson gson = new Gson();
        HashMap<String, Object> dataMap = gson.fromJson(wjson, HashMap.class);
        Weather retVal = new Weather();
        retVal.lowTemp = ((Double) ((Map) ((Map) ((ArrayList) dataMap.get("list")).get(2)).get("main")).get("temp_min"))
                .floatValue() - ZERO_KELVIN;
        retVal.highTemp =
                ((Double) ((Map) ((Map) ((ArrayList) dataMap.get("list")).get(2)).get("main")).get("temp_max"))
                        .floatValue() - ZERO_KELVIN;

        return retVal;
    }


    public Weather getWeather(String city) throws Exception {
        WeatherService ws = new WeatherService();
        return ws.getWeather(city);
    }

    public static void main(String[] args) throws Exception {
        WeatherServicePlus wp = new WeatherServicePlus();
        Weather w = wp.getTomorrowForecast("bengaluru");
        System.out.println("Tomorrow temperature max = " + w.highTemp);
    }
}
