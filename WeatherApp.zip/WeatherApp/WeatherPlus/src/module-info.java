import com.mydomain.weather.weatherapi.WeatherApi;
import com.mydomain.weatherplus.WeatherServicePlus;

module weatherpluslib {
    requires weatherlib;
    requires WeatherApi;
    provides WeatherApi with WeatherServicePlus;
}