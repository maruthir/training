module httplib {
    exports com.mydomain.httplib;
}