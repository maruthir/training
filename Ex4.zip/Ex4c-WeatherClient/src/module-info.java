module weatherclient {
    requires weatherapi;
    requires weatherlib;

}