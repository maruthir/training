package com.mydomain.weather.client;

import com.mydomain.providers.weather.WeatherApi;
import com.mydomain.weather.Weather;

public class WeatherClient {

    public static void main(String[] args) throws Exception {
        WeatherApi api = WeatherApi.getInstances().get(0);
        Weather w = api.getTomorrowForecast("bengaluru");
        System.out.println("Forecast for tomorrow max temperature = " + w.highTemp);
    }
}
