import com.mydomain.providers.weather.WeatherApi;

module weatherapi {
    requires weatherlib;

    exports com.mydomain.providers.weather;
    uses WeatherApi;
}