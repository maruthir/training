import com.mydomain.provider.weatherplus.WeatherServicePlus;
import com.mydomain.providers.weather.WeatherApi;

module weatherpluslib {
    requires weatherlib;
    requires httplib;
    requires gsonlib;
    requires weatherapi;

    provides WeatherApi with WeatherServicePlus;
}