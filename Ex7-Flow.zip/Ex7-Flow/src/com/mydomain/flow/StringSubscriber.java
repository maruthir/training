package com.mydomain.flow;

import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.Flow.Subscription;

public class StringSubscriber implements Subscriber<String> {

    Subscription subscription;

    @Override
    public void onSubscribe(Subscription subscription) {
        this.subscription = subscription;
        subscription.request(1);//Set buffer to 1
    }

    @Override
    public void onNext(String item) {
        System.out.println("Event received: " + item);
        new Thread() {
            public void run() {
                subscription.request(1);
            }
        }.start();
    }

    @Override
    public void onError(Throwable throwable) {
        System.out.println("Error received: " + throwable.getMessage());
    }

    @Override
    public void onComplete() {
        System.out.println("Subscription complete");
    }
}
