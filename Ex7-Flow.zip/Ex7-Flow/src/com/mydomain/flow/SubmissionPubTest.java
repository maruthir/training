package com.mydomain.flow;

import java.util.Arrays;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.Flow.Subscription;
import java.util.concurrent.SubmissionPublisher;

public class SubmissionPubTest {

    public static CountDownLatch latch;

    public static void main(String[] args) throws InterruptedException {
        // Create a publisher.

        SubmissionPublisher<String> publisher = new SubmissionPublisher<>();

        // Create a subscriber and register it with the publisher.

        latch = new CountDownLatch(2);
        ContinuousSubscriber<String> subscriber = new ContinuousSubscriber<>();
        publisher.subscribe(subscriber);

        BatchSubscriber<String> subscriber2 = new BatchSubscriber<>();
        publisher.subscribe(subscriber2);

        // Publish several data items and then close the publisher.

        System.out.println("Publishing data items...");
        String[] items = {"jan", "feb", "mar", "apr", "may", "jun",
                "jul", "aug", "sep", "oct", "nov", "dec"};
        Arrays.asList(items).stream().forEach(i -> publisher.submit(i));
        for(int i=0; i< 100000; i++ ){
            publisher.submit(""+i);
        }

        publisher.close();

        latch.await();
    }
}

class ContinuousSubscriber<T> implements Subscriber<T> {

    private Subscription subscription;

    @Override
    public void onSubscribe(Subscription subscription) {
        this.subscription = subscription;
        subscription.request(1);
    }

    @Override
    public void onNext(T item) {
        System.out.println("Received: " + item);
        subscription.request(1);
    }

    @Override
    public void onError(Throwable t) {
        t.printStackTrace();
        SubmissionPubTest.latch.countDown();
    }

    @Override
    public void onComplete() {
        System.out.println("Done");
        SubmissionPubTest.latch.countDown();
    }
}

class BatchSubscriber<T> implements Subscriber<T> {

    private Subscription subscription;

    Queue<String> messages = new ConcurrentLinkedQueue<>();

    @Override
    public void onSubscribe(Subscription subscription) {
        this.subscription = subscription;
        subscription.request(5);
    }

    @Override
    public void onNext(T item) {
        messages.offer((String) item);
        if (messages.size() % 5 == 0) {
            System.out.println(messages.stream().reduce("", (a, b) -> a + ", " + b));
            messages.clear();
            subscription.request(5);
        }
    }

    @Override
    public void onError(Throwable t) {
        t.printStackTrace();
        SubmissionPubTest.latch.countDown();
    }

    @Override
    public void onComplete() {
        System.out.println("Done");
        SubmissionPubTest.latch.countDown();
    }
}
