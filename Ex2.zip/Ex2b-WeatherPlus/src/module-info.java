import com.mydomain.weatherplus.WeatherServicePlus;

module weatherpluslib {
    requires weatherlib;
    requires httplib;
    requires gsonlib;
}