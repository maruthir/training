
module weatherlib {
	requires transitive httplib;
	requires gsonlib;
	requires java.sql;

	exports com.mydomain.weather;
}