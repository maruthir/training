package com.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.model.User;
import com.service.UserManager;

@RestController
@RequestMapping("/users")
public class UserResource {
	
	@Autowired
	UserManager userManager;
	
	@RequestMapping(method=RequestMethod.GET, value="/", 
			produces=MediaType.APPLICATION_JSON_VALUE)
	public List<User> getUsers() throws Exception{
		System.out.println("UserResource::getUsers");
		return userManager.getAllUsers();
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/", 
			consumes=MediaType.APPLICATION_JSON_VALUE, 
			produces=MediaType.APPLICATION_JSON_VALUE)
	public Map<String,String> addUsers(@RequestBody User u) throws Exception{
		System.out.println("UserResource::addUsers: "+u);
		userManager.addUser(u);
		HashMap m = new HashMap();
		m.put("status", "success");
		return m;
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/", 
			consumes=MediaType.APPLICATION_JSON_VALUE, 
			produces=MediaType.APPLICATION_JSON_VALUE)
	public Map<String,String> updateUsers(@RequestBody User u) throws Exception{
		System.out.println("UserResource::updateUsers: "+u);
		userManager.updateUser(u);
		HashMap m = new HashMap();
		m.put("status", "success");
		return m;
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/{uid}", 
			produces=MediaType.APPLICATION_JSON_VALUE)
	public Map<String,String> deleteUsers(@PathVariable("uid") Integer id) throws Exception{
		System.out.println("UserResource::deleteUsers: "+id);
		userManager.deleteUser(id);
		HashMap m = new HashMap();
		m.put("status", "success");
		return m;
	}
}
