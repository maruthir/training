package com.mydomain;

public class Main {

    public static void main(String[] args) {
        System.out.println("Current process id: " + ProcessUtil.getPid());
    }
}
